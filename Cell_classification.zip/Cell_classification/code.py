# -*- coding: utf-8 -*-
"""

@author: pedda
"""

import tensorflow as tf
import cv2
import os

def load_images_from_folder(folder):
    images = []
    for filename in os.listdir(folder):
        img = cv2.imread(os.path.join(folder,filename))
        if img is not None:
            images.append(img)
    return images



test_images = load_images_from_folder(r"C:\Users\pedda\Desktop\data\test")
train_images = load_images_from_folder(r"C:\Users\pedda\Desktop\data\training")
validation_images = load_images_from_folder(r"C:\Users\pedda\Desktop\data\validation")

#%%

print(f"Type of test images is : {type(test_images)}")
print(f"Type of training images is : {type(train_images)}")
print(f"Type of validation images is : {type(validation_images)}")


#%%

import numpy as np

x_test = np.array(test_images)
x_train =  np.array(train_images)
x_validation =  np.array(validation_images)

#%%

print(f"Type of test images is : {type(x_test)}")
print(f"Type of training images is : {type(x_train)}")
print(f"Type of validation images is : {type(x_validation)}")


#%%

import pandas as pd

image_class = pd.read_csv(r"C:\Users\pedda\Desktop\data\gt_training.csv")
img_class = np.array(image_class)



#%%


import numpy as np 
from keras.preprocessing import image

PATH = ""

train_path = PATH+'C:\\Users\\pedda\\Desktop\\data\\training'
train_images_name = os.listdir(train_path)


x_train_name = []



# if data are in form of images
for sample in x_train_name:
	img_path = train_path+sample
	x = image.load_img(img_path)
	# preprocessing if required
	x_train.append(x)
    
test_path = PATH+'C:\\Users\\pedda\\Desktop\\data\\test'
test_images_name = os.listdir(test_path)


x_test_name = []


for sample in x_test_name:
	img_path = test_path+sample
	x = image.load_img(img_path)
	# preprocessing if required
	x_test.append(x)
    

validation_path = PATH+'C:\\Users\\pedda\\Desktop\\data\\validation'
validation_images_name = os.listdir(validation_path)  

x_validation_name = []


for sample in x_validation_name:
	img_path = validation_path+sample
	x = image.load_img(img_path)
	# preprocessing if required
	x_validation.append(x)

#%%
    
x_train_name = np.array(train_images_name)
x_test_name = np.array(test_images_name)
x_validation_name = np.array(validation_images_name)



#%%
x_test_labled = []
x_train_labled = []
x_validation_labled = []

for i in x_test_name:
    num = int(i[0:5]) - 1
    x_test_labled.append(img_class[num][1])

for i in x_train_name:
    num = int(i[0:5]) - 1
    x_train_labled.append(img_class[num][1])

for i in x_validation_name:
    num = int(i[0:5]) - 1
    x_validation_labled.append(img_class[num][1])

#%%
    
classes = {"Homogeneous" : 0, "Speckled" : 1, "Nucleolar" : 2, "Centromere" : 3, "NuMem" : 4, "Golgi" : 5}

x_test_labled_index = []
for i in x_test_labled:
    x_test_labled_index.append(classes[i])

x_train_labled_index = []
for i in x_train_labled:
    x_train_labled_index.append(classes[i])

x_validation_labled_index = []
for i in x_validation_labled:
    x_validation_labled_index.append(classes[i])

#%%

x_test_labled_index = np.array(x_test_labled_index)
x_train_labled_index = np.array(x_train_labled_index)
x_validation_labled_index = np.array(x_validation_labled_index)




#%%
from keras.utils import to_categorical
x_validation_labled_index = to_categorical(x_validation_labled_index)
x_test_labled_index = to_categorical(x_test_labled_index)
x_train_labled_index = to_categorical(x_train_labled_index)



"""
#adding the layers in the model
model.add(Conv2D(64, kernel_size=7, activation='tanh', input_shape=(78,78,3)))
model.add(MaxPooling2D(pool_size=(2, 2),strides=(1, 1), padding='valid'))
model.add(Conv2D(32, kernel_size=4, activation='tanh'))
model.add(MaxPooling2D(pool_size=(3, 3),strides=(1, 1), padding='valid'))
model.add(Conv2D(32, kernel_size=3, activation='tanh'))
model.add(MaxPooling2D(pool_size=(4, 4),strides=(1, 1), padding='valid'))

"""



import tensorflow as tf
from keras.models import Sequential
from keras.layers import Dense, Conv2D, Flatten, MaxPooling2D

#from keras.layers.pooling import *

#creating a model
model = Sequential()

#max_pool_2d = tf.keras.layers.MaxPooling2D(pool_size=(2, 2),strides=(1, 1), padding='valid')


#adding the layers in the model
model.add(Conv2D(64, kernel_size=3, activation='tanh', input_shape=(78,78,3)))
model.add(Conv2D(32, kernel_size=3, activation='tanh'))
model.add(Conv2D(32, kernel_size=3, activation='tanh'))
model.add(Flatten())


model.add(Dense(6, activation='softmax'))


#Model compilation using accuracy to test the performance of the model
model.compile(optimizer='adam', loss='categorical_crossentropy', metrics=['accuracy'])


#train the model
model.fit(x_train,x_train_labled_index , validation_data=(x_validation,x_validation_labled_index), epochs=5)
    


#%%

#predict first 5 images in the test set
print("Predicting the values of First 5 images in the test data")
predicted_images  = model.predict(x_test[:5])

print(predicted_images)


# Test results for the Original outputs
print("Verifying the predicted images with Actual images")
Actual_labels = x_test_labled_index[:5]


print(Actual_labels)

#%%

# Checking the Accuracy on the Test images data
score, acc = model.evaluate(x_test, x_test_labled_index,
                            batch_size = 32)
print('Test score:', score)
print('Test accuracy:', acc)
